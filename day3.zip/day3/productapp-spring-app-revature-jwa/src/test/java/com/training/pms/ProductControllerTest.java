package com.training.pms;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.training.pms.model.Product;
@TestMethodOrder(value = MethodOrderer.OrderAnnotation.class)
public class ProductControllerTest extends AbstractTest {

	int productId = 99999; 
	String uri = "/product";

	@Override
	@BeforeEach
	protected void setUp() {
		super.setUp();
	}
	
	@Test
	@DisplayName(value = "Testing save product")
	@Order(1)
	public void testSaveProduct() throws Exception {
		Product product = new Product(productId, "DummyProduct", 100, 1006);
		//json
		String productJSON = super.mapToJson(product);
		
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.post(uri)
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(productJSON)).andReturn();
		
		int status = mvcResult.getResponse().getStatus();
		assertEquals(201, status);
		String content = mvcResult.getResponse().getContentAsString();
		assertEquals(content, "Product saved successfully");
	}
	
	@Test
	@DisplayName(value = "Testing update product")
	@Order(2)
	public void testUpdateProduct() throws Exception {

		Product product = new Product(productId, "UpdateDummyProduct", 99, 187);
		//json
		String productJSON = super.mapToJson(product);
		
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.put(uri)
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(productJSON)).andReturn();
		
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		assertEquals(content, "Product updated successfully");
	}
	
	@Test
	@DisplayName(value = "Testing get all products")
	@Order(3)
	public void testGetProducts() throws Exception {

		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri)
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andReturn();
		
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		Product []productList = super.mapFromJson(content, Product[].class);
		assertTrue(productList.length > 0);
	}
	
	//test get a single record by productId	- Hands -0n
	@Test
	@DisplayName(value = "Testing get product by id")
	@Order(4)
	public void testProductById() throws Exception {
		
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri+"/"+productId)
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andReturn();
		
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		Product product = super.mapFromJson(content, Product.class);
		assertEquals(productId, product.getProductId());
		assertEquals("UpdateDummyProduct", product.getProductName());
	}

	
	@Test
	@DisplayName(value = "Testing delete product")
	@Order(5)
	public void testDeleteProduct() throws Exception {

		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.delete(uri+"/"+productId)
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andReturn();
		
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		
		assertEquals(content, "Product deleted successfully");
	}
	
}
