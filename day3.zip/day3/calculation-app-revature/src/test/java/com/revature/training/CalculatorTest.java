package com.revature.training;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class CalculatorTest {
	//object of calculator created and initialized
	Calculator calculator = new Calculator();
	
	@Test
	@DisplayName(value = "Testing sum - 1")
	void testSum1() {
		int expected =10;
		int actual = calculator.sum(5,5);
		assertEquals(expected, actual);
	}

	@Test
	@DisplayName(value = "Testing sum - 2")
	void testSum2() {
		int expected =10;
		int actual = calculator.sum(2,8);
		assertEquals(expected, actual);
	}
	
	@Test
	@DisplayName(value = "Testing Multiple")
	void testMultiply() {
		int expected =10;
		int actual = calculator.multiply(5,2);
		assertEquals(expected, actual);
	}

	@Test
	@DisplayName(value = "Testing substract")
	void testSubstract() {
		int expected =10;
		int actual = calculator.substract(30,20);
		assertEquals(expected, actual);
		calculator=null;
	}

}
