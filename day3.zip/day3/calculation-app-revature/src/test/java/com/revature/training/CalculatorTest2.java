package com.revature.training;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(value = MethodOrderer.OrderAnnotation.class)
class CalculatorTest2 {

	Calculator calculator;
	int expected;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("###setUpBeforeClass called");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("###tearDownAfterClass called");
	}

	@BeforeEach
	void setUp() throws Exception {
		System.out.println("###setUp called");
		expected = 10;
		calculator = new Calculator();
	}

	@AfterEach
	void tearDown() throws Exception {
		System.out.println("###tearDown called");
		expected = 0;
		calculator = null;
	}

	@Test
	@DisplayName(value = "Testing sum - 1")
	@Order(1)
	void testSum1() {
		System.out.println("###testSum1 called");
		int actual = calculator.sum(5, 5);
		assertEquals(expected, actual);
	}

	@Test
	@DisplayName(value = "Testing sum - 2")
	@Order(4)
	void testSum2() {
		System.out.println("###testSum2 called");

		int actual = calculator.sum(2, 8);
		assertEquals(expected, actual);
	}

	@Test
	@DisplayName(value = "Testing Multiply")
	@Order(2)
	void testMultiply() {
		System.out.println("###testMultiply called");

		int actual = calculator.multiply(5, 2);
		assertEquals(expected, actual);
	}

	@Test
	@DisplayName(value = "Testing substract")
	@Order(3)
	void testSubstract() {
		System.out.println("###testSubstract called");
		int actual = calculator.substract(30, 20);
		assertEquals(expected, actual);
	}

	@Test
	@DisplayName(value = "Testing Converting number \"90\"")
	@Order(5)
	void testConvertToNumber1() {
		System.out.println("###testConvertToNumber1 called");
		int actual = calculator.convertToNumber("90");
		int result = actual + 2;
		assertEquals(92, result);
	}
	@Test
	@DisplayName(value = "Testing Converting number \"ninety\"")
	@Order(6)
	void testConvertToNumber2() {
		System.out.println("###testConvertToNumber2 called");
		assertThrows(NumberFormatException.class, () -> {
			int actual = calculator.convertToNumber("ten");
			int result = actual + 2;
			assertEquals(92, result);
		});

	}
	@Test
	@DisplayName(value = "Testing divide number 10/0")
	@Order(7)
	void testDivide1() {
		int actual = calculator.divide(10,2);
		assertEquals(5, actual);
	}
	@Test
	@DisplayName(value = "Testing divide number 10/0")
	@Order(8)
	void testDivide2() {
		assertThrows(ArithmeticException.class, () -> {
			int actual = calculator.divide(10,0);
			assertEquals(0, actual);
		});

	}

}
