package com.revature.training;

public class Calculator {

	public int sum(int num1,int num2) {
		return num1+num2;
	}
	public int multiply(int num1,int num2) {
		return num1*num2;
	}
	public int substract(int num1,int num2) {
		return num1-num2;
	}
	
	//converttoNumber -- string -->int
	public int convertToNumber(String num) {
		return Integer.parseInt(num);
	}
	//"90"	= 902
	// "Ninety"	--
	//90 +2 = 92
	
	
	//10/5
	//10/0	- ArithmeticException
	public int divide(int num1,int num2) {
		int result= 0;
		try {
			result = num1/num2;
		} catch (ArithmeticException e) {
			 throw new ArithmeticException();
		}
		
		return result;
	}
}
